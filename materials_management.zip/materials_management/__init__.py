def load_views():
    from . import material_views

